package com.example.a16;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button helloBtn, sendBtn;

    EditText playerName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        helloBtn = findViewById(R.id.helloBtn);

        sendBtn = findViewById(R.id.sendBtn);

        playerName = findViewById(R.id.playerName);

        // Q1 - Send Hello Message
        helloBtn.setOnClickListener(v -> {

            Intent intent =
                    new Intent(MainActivity.this,
                            SecondActivity.class);

            intent.putExtra("message",
                    "Hello");

            startActivity(intent);
        });

        // Q2 - Send Player Name
        sendBtn.setOnClickListener(v -> {

            String name =
                    playerName.getText().toString();

            Intent intent =
                    new Intent(MainActivity.this,
                            SecondActivity.class);

            intent.putExtra("message",
                    "Player Name : " + name);

            startActivity(intent);
        });
    }
}
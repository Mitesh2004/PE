package com.example.a16;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    TextView result;

    Button backBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        result = findViewById(R.id.result);

        backBtn = findViewById(R.id.backBtn);

        // Receive Intent Data
        String msg =
                getIntent().getStringExtra("message");

        result.setText(msg);

        // Back Button
        backBtn.setOnClickListener(v -> finish());
    }
}

package com.example.a2;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText num1, num2, perfectNum;
    TextView result;

    Button add, sub, mul, div, checkPerfect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Calculator Views
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);

        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        mul = findViewById(R.id.mul);
        div = findViewById(R.id.div);

        // Perfect Number Views
        perfectNum = findViewById(R.id.perfectNum);
        checkPerfect = findViewById(R.id.checkPerfect);

        // Result
        result = findViewById(R.id.result);

        // Arithmetic Operations
        add.setOnClickListener(v -> calculate("+"));

        sub.setOnClickListener(v -> calculate("-"));

        mul.setOnClickListener(v -> calculate("*"));

        div.setOnClickListener(v -> calculate("/"));

        // Perfect Number Check
        checkPerfect.setOnClickListener(v -> checkPerfectNumber());
    }

    // Calculator Method
    private void calculate(String op) {

        String n1 = num1.getText().toString();
        String n2 = num2.getText().toString();

        if (n1.isEmpty() || n2.isEmpty()) {
            result.setText("Enter both numbers");
            return;
        }

        double a = Double.parseDouble(n1);
        double b = Double.parseDouble(n2);

        double res = 0;

        switch (op) {

            case "+":
                res = a + b;
                break;

            case "-":
                res = a - b;
                break;

            case "*":
                res = a * b;
                break;

            case "/":

                if (b == 0) {
                    result.setText("Cannot divide by zero");
                    return;
                }

                res = a / b;
                break;
        }

        result.setText("Calculator Result = " + res);
    }

    // Perfect Number Method
    private void checkPerfectNumber() {

        String input = perfectNum.getText().toString();

        if (input.isEmpty()) {

            Toast.makeText(this,
                    "Enter number",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        int num = Integer.parseInt(input);

        int sum = 0;

        for (int i = 1; i <= num / 2; i++) {

            if (num % i == 0) {
                sum += i;
            }
        }

        if (sum == num && num != 0) {

            Toast.makeText(this,
                    num + " is Perfect Number",
                    Toast.LENGTH_LONG).show();

        } else {
            Toast.makeText(this,
                    num + " is NOT Perfect Number",
                    Toast.LENGTH_LONG).show();
        }
    }
}

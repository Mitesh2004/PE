package com.example.a14;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Factorial
    EditText number;
    Button factBtn;
    TextView result;

    // Login
    EditText username, password;
    Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Factorial Views
        number = findViewById(R.id.number);

        factBtn = findViewById(R.id.factBtn);

        result = findViewById(R.id.result);

        // Login Views
        username = findViewById(R.id.username);

        password = findViewById(R.id.password);

        loginBtn = findViewById(R.id.loginBtn);

        // Factorial Button
        factBtn.setOnClickListener(v -> calculateFactorial());

        // Login Button
        loginBtn.setOnClickListener(v -> checkLogin());
    }

    // Factorial Program
    private void calculateFactorial() {

        String input =
                number.getText().toString();

        if (input.isEmpty()) {

            result.setText("Enter Number");

            return;
        }

        int num = Integer.parseInt(input);

        long fact = 1;

        for (int i = 1; i <= num; i++) {

            fact = fact * i;
        }

        result.setText(
                "Factorial of " + num + " = " + fact);
    }

    // Login Program
    private void checkLogin() {

        String user =
                username.getText().toString();

        String pass =
                password.getText().toString();

        if (user.equals(pass)) {

            Toast.makeText(this,
                    "Login Successful...",
                    Toast.LENGTH_LONG).show();

        } else {

            Toast.makeText(this,
                    "Invalid Login",
                    Toast.LENGTH_LONG).show();
        }
    }
}
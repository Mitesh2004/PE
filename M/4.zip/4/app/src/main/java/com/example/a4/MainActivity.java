
package com.example.a4;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageSwitcher imageSwitcher;
    Button nextBtn, prevBtn, searchBtn;
    EditText location;

    int[] images = {
            R.drawable.img1,
            R.drawable.img2,
            R.drawable.img3
    };

    int index = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageSwitcher = findViewById(R.id.imageSwitcher);

        nextBtn = findViewById(R.id.nextBtn);
        prevBtn = findViewById(R.id.prevBtn);

        searchBtn = findViewById(R.id.searchBtn);

        location = findViewById(R.id.location);

        // setFactory()
        imageSwitcher.setFactory(() -> {

            ImageView imageView = new ImageView(getApplicationContext());

            imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

            imageView.setLayoutParams(
                    new ImageSwitcher.LayoutParams(
                            ImageSwitcher.LayoutParams.MATCH_PARENT,
                            ImageSwitcher.LayoutParams.MATCH_PARENT
                    )
            );

            return imageView;
        });

        // First Image
        imageSwitcher.setImageResource(images[index]);

        // Next Button
        nextBtn.setOnClickListener(v -> {

            index = (index + 1) % images.length;

            imageSwitcher.setImageResource(images[index]);
        });

        // Previous Button
        prevBtn.setOnClickListener(v -> {

            index = (index - 1 + images.length) % images.length;

            imageSwitcher.setImageResource(images[index]);
        });

        // Google Map Search
        searchBtn.setOnClickListener(v -> searchLocation());
    }

    private void searchLocation() {

        String loc = location.getText().toString();

        if (loc.isEmpty()) {

            Toast.makeText(this,
                    "Enter Location",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        Uri uri = Uri.parse("geo:0,0?q=" + Uri.encode(loc));

        Intent intent = new Intent(Intent.ACTION_VIEW, uri);

        intent.setPackage("com.google.android.apps.maps");

        startActivity(intent);
    }
}
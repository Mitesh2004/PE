
package com.example.a3;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText armstrongNum, phone;
    Button checkArmstrong, checkPhone;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        armstrongNum = findViewById(R.id.armstrongNum);
        phone = findViewById(R.id.phone);

        checkArmstrong = findViewById(R.id.checkArmstrong);
        checkPhone = findViewById(R.id.checkPhone);

        result = findViewById(R.id.result);

        // Armstrong Check
        checkArmstrong.setOnClickListener(v -> checkArmstrong());

        // Phone Validation
        checkPhone.setOnClickListener(v -> validatePhone());
    }

    // Armstrong Number Program
    private void checkArmstrong() {

        String input = armstrongNum.getText().toString();

        if (input.isEmpty()) {
            result.setText("Enter a number");
            return;
        }

        int num = Integer.parseInt(input);
        int original = num;
        double sum = 0;
        int digits = input.length();

        while (num > 0) {

            int digit = num % 10;

            sum = sum + Math.pow(digit, digits);

            num = num / 10;
        }

        if (sum == original) {

            result.setText(original + " is Armstrong Number");

        } else {

            result.setText(original + " is NOT Armstrong Number");
        }
    }

    // Phone Validation Program
    private void validatePhone() {

        String number = phone.getText().toString().trim();

        // Valid Area Codes:
        // 040,041,050,0400,044
        // Total digits 6-8

        String pattern = "^(0400|040|041|050|044)\\d{2,4}$";

        if (number.matches(pattern)) {

            result.setText("Valid Phone Number");

        } else {

            result.setText("Invalid Phone Number");
        }
    }
}

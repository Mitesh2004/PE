
package com.example.a5;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button dialogBtn, displayBtn, clearBtn, exitBtn;

    EditText name, message;

    CheckBox bold, italic, underline;

    RadioGroup colorGroup;

    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dialogBtn = findViewById(R.id.dialogBtn);

        name = findViewById(R.id.name);
        message = findViewById(R.id.message);

        bold = findViewById(R.id.bold);
        italic = findViewById(R.id.italic);
        underline = findViewById(R.id.underline);

        colorGroup = findViewById(R.id.colorGroup);

        displayBtn = findViewById(R.id.displayBtn);
        clearBtn = findViewById(R.id.clearBtn);
        exitBtn = findViewById(R.id.exitBtn);

        result = findViewById(R.id.result);

        // Alert Dialog
        dialogBtn.setOnClickListener(v -> showDialogBox());

        // Display Message
        displayBtn.setOnClickListener(v -> displayMessage());

        // Clear
        clearBtn.setOnClickListener(v -> clearData());

        // Exit
        exitBtn.setOnClickListener(v -> finish());
    }

    // Alert Dialog Method
    private void showDialogBox() {

        AlertDialog.Builder builder =
                new AlertDialog.Builder(this);

        builder.setTitle("Alert Dialog");

        builder.setMessage("Do you want to continue?");

        builder.setPositiveButton("Yes",
                (dialog, which) ->
                        Toast.makeText(this,
                                "Yes Clicked",
                                Toast.LENGTH_SHORT).show());

        builder.setNegativeButton("No",
                (dialog, which) ->
                        Toast.makeText(this,
                                "No Clicked",
                                Toast.LENGTH_SHORT).show());

        builder.show();
    }

    // Display Message Method
    private void displayMessage() {

        String n = name.getText().toString();

        String msg = message.getText().toString();

        String finalText = n + " : " + msg;

        result.setText(finalText);

        // Bold & Italic
        int style = Typeface.NORMAL;

        if (bold.isChecked() && italic.isChecked()) {

            style = Typeface.BOLD_ITALIC;

        } else if (bold.isChecked()) {

            style = Typeface.BOLD;

        } else if (italic.isChecked()) {

            style = Typeface.ITALIC;
        }

        result.setTypeface(null, style);

        // Underline
        if (underline.isChecked()) {

            result.setPaintFlags(
                    result.getPaintFlags()
                            | Paint.UNDERLINE_TEXT_FLAG);

        } else {

            result.setPaintFlags(
                    result.getPaintFlags()
                            & (~Paint.UNDERLINE_TEXT_FLAG));
        }

        // Text Color
        int selected = colorGroup.getCheckedRadioButtonId();

        if (selected == R.id.red) {

            result.setTextColor(Color.RED);

        } else if (selected == R.id.green) {

            result.setTextColor(Color.GREEN);

        } else if (selected == R.id.blue) {

            result.setTextColor(Color.BLUE);
        }
    }

    // Clear Method
    private void clearData() {

        name.setText("");
        message.setText("");

        result.setText("");

        bold.setChecked(false);
        italic.setChecked(false);
        underline.setChecked(false);

        colorGroup.clearCheck();
    }
}

package com.example.a9;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Palindrome
    EditText getnum;
    Button checkBtn;

    // Calculator
    EditText num1, num2;
    Button add, sub, mul, div;

    // Result
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Palindrome
        getnum = findViewById(R.id.getnum);
        checkBtn = findViewById(R.id.checkBtn);

        // Calculator
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);

        add = findViewById(R.id.add);
        sub = findViewById(R.id.sub);
        mul = findViewById(R.id.mul);
        div = findViewById(R.id.div);

        // Result
        result = findViewById(R.id.result);

        // Palindrome Check
        checkBtn.setOnClickListener(v -> checkPalindrome());

        // Calculator Operations
        add.setOnClickListener(v -> calculate("+"));

        sub.setOnClickListener(v -> calculate("-"));

        mul.setOnClickListener(v -> calculate("*"));

        div.setOnClickListener(v -> calculate("/"));
    }

    // Palindrome Program
    private void checkPalindrome() {

        String input =
                getnum.getText().toString();

        if (input.isEmpty()) {

            result.setText("Enter Number");

            return;
        }

        int num = Integer.parseInt(input);

        int original = num;

        int reverse = 0;

        while (num > 0) {

            int digit = num % 10;

            reverse = reverse * 10 + digit;

            num = num / 10;
        }

        if (original == reverse) {

            result.setText(
                    original + " is Palindrome");

        } else {

            result.setText(
                    original + " is NOT Palindrome");
        }
    }

    // Calculator Program
    private void calculate(String op) {

        String n1 =
                num1.getText().toString();

        String n2 =
                num2.getText().toString();

        if (n1.isEmpty() || n2.isEmpty()) {

            result.setText("Enter Both Numbers");

            return;
        }

        double a = Double.parseDouble(n1);

        double b = Double.parseDouble(n2);

        double res = 0;

        switch (op) {

            case "+":
                res = a + b;
                break;

            case "-":
                res = a - b;
                break;

            case "*":
                res = a * b;
                break;

            case "/":

                if (b == 0) {

                    result.setText(
                            "Cannot Divide By Zero");

                    return;
                }

                res = a / b;
                break;
        }

        result.setText("Calculator Result = " + res);
    }
}
package com.example.a15;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Calculator
    EditText num1, num2;

    Button addBtn, subBtn, mulBtn, divBtn;

    // Bank App
    Spinner spinner;

    Button showBtn;

    TextView result;

    String[] menuItems = {
            "Select Menu",
            "Account Number",
            "Account Type",
            "Balance",
            "Checking",
            "Saving",
            "Create Account",
            "Withdraw",
            "Deposit"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Calculator Views
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);

        addBtn = findViewById(R.id.addBtn);
        subBtn = findViewById(R.id.subBtn);
        mulBtn = findViewById(R.id.mulBtn);
        divBtn = findViewById(R.id.divBtn);

        // Bank Views
        spinner = findViewById(R.id.spinner);

        showBtn = findViewById(R.id.showBtn);

        result = findViewById(R.id.result);

        // Spinner Adapter
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        menuItems
                );

        spinner.setAdapter(adapter);

        // Calculator Buttons
        addBtn.setOnClickListener(v -> calculate("+"));

        subBtn.setOnClickListener(v -> calculate("-"));

        mulBtn.setOnClickListener(v -> calculate("*"));

        divBtn.setOnClickListener(v -> calculate("/"));

        // Bank Menu Button
        showBtn.setOnClickListener(v -> showMenu());
    }

    // Calculator Program
    private void calculate(String op) {

        String n1 =
                num1.getText().toString();

        String n2 =
                num2.getText().toString();

        if (n1.isEmpty() || n2.isEmpty()) {

            Toast.makeText(this,
                    "Enter Both Numbers",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        double a = Double.parseDouble(n1);

        double b = Double.parseDouble(n2);

        double res = 0;

        switch (op) {

            case "+":
                res = a + b;
                break;

            case "-":
                res = a - b;
                break;

            case "*":
                res = a * b;
                break;

            case "/":

                if (b == 0) {

                    Toast.makeText(this,
                            "Cannot Divide By Zero",
                            Toast.LENGTH_SHORT).show();

                    return;
                }

                res = a / b;
                break;
        }

        Toast.makeText(this,
                "Result = " + res,
                Toast.LENGTH_LONG).show();
    }

    // Bank Menu Program
    private void showMenu() {

        String selected =
                spinner.getSelectedItem().toString();

        switch (selected) {

            case "Account Number":

                result.setText("Account No : 123456789");
                break;

            case "Account Type":

                result.setText("Account Type : Saving");
                break;

            case "Balance":

                result.setText("Balance : ₹50,000");
                break;

            case "Checking":

                result.setText("Checking Account Selected");
                break;

            case "Saving":

                result.setText("Saving Account Selected");
                break;

            case "Create Account":

                result.setText("New Account Created");
                break;

            case "Withdraw":

                result.setText("Withdraw Successful");
                break;

            case "Deposit":

                result.setText("Deposit Successful");
                break;

            default:

                result.setText("Select Valid Menu");
        }
    }
}
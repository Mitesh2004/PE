package com.example.a23;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Implicit Intent
    Button openBrowserBtn;

    // Formatting App
    EditText name, message;

    CheckBox bold, italic, underline;

    RadioGroup colorGroup;

    Button displayBtn, clearBtn, exitBtn;

    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Implicit Intent
        openBrowserBtn =
                findViewById(R.id.openBrowserBtn);

        // Formatting App
        name = findViewById(R.id.name);

        message = findViewById(R.id.message);

        bold = findViewById(R.id.bold);

        italic = findViewById(R.id.italic);

        underline = findViewById(R.id.underline);

        colorGroup =
                findViewById(R.id.colorGroup);

        displayBtn =
                findViewById(R.id.displayBtn);

        clearBtn =
                findViewById(R.id.clearBtn);

        exitBtn =
                findViewById(R.id.exitBtn);

        result =
                findViewById(R.id.result);

        // Open Browser
        openBrowserBtn.setOnClickListener(v -> {

            Intent intent =
                    new Intent(
                            Intent.ACTION_VIEW,
                            Uri.parse("https://www.google.com")
                    );

            startActivity(intent);
        });

        // Display Button
        displayBtn.setOnClickListener(v -> displayMessage());

        // Clear Button
        clearBtn.setOnClickListener(v -> clearData());

        // Exit Button
        exitBtn.setOnClickListener(v -> finish());
    }

    // Display Message
    private void displayMessage() {

        String n =
                name.getText().toString();

        String msg =
                message.getText().toString();

        result.setText(n + " : " + msg);

        // Bold & Italic
        int style = Typeface.NORMAL;

        if (bold.isChecked() &&
                italic.isChecked()) {

            style = Typeface.BOLD_ITALIC;

        } else if (bold.isChecked()) {

            style = Typeface.BOLD;

        } else if (italic.isChecked()) {

            style = Typeface.ITALIC;
        }

        result.setTypeface(null, style);

        // Underline
        if (underline.isChecked()) {

            result.setPaintFlags(
                    result.getPaintFlags()
                            | Paint.UNDERLINE_TEXT_FLAG);

        } else {

            result.setPaintFlags(
                    result.getPaintFlags()
                            & (~Paint.UNDERLINE_TEXT_FLAG));
        }

        // Color
        int selected =
                colorGroup.getCheckedRadioButtonId();

        if (selected == R.id.red) {

            result.setTextColor(Color.RED);

        } else if (selected == R.id.green) {

            result.setTextColor(Color.GREEN);

        } else if (selected == R.id.blue) {

            result.setTextColor(Color.BLUE);
        }
    }

    // Clear Method
    private void clearData() {

        name.setText("");

        message.setText("");

        result.setText("");

        bold.setChecked(false);

        italic.setChecked(false);

        underline.setChecked(false);

        colorGroup.clearCheck();
    }
}
package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class NumberService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        int number = Integer.parseInt(request.getParameter("number"));

        String type = request.getParameter("type");

        String result = "";

        if(type.equals("Binary"))
            result = Integer.toBinaryString(number);

        else if(type.equals("Octal"))
            result = Integer.toOctalString(number);

        else if(type.equals("Hexadecimal"))
            result = Integer.toHexString(number);

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<h2>Converted Value : " + result + "</h2>");
    }
}
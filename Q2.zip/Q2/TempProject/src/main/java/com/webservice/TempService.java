package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class TempService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        double celsius = Double.parseDouble(request.getParameter("celsius"));

        double fahrenheit = (celsius * 9 / 5) + 32;

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<h2>Fahrenheit Value : " + fahrenheit + "</h2>");
    }
}
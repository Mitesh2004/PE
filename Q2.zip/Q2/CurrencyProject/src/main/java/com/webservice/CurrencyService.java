package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class CurrencyService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        double rupees = Double.parseDouble(request.getParameter("rupees"));

        String type = request.getParameter("type");

        double result = 0;
        String currencyName = "";

        if(type.equals("Dollar")) {
            result = rupees / 83;
            currencyName = "USD Dollar";
        }

        else if(type.equals("Euro")) {
            result = rupees / 90;
            currencyName = "Euro";
        }

        else if(type.equals("Pound")) {
            result = rupees / 100;
            currencyName = "British Pound";
        }

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<h2>Converted Amount : "
                + String.format("%.2f", result)
                + " " + currencyName
                + "</h2>");
    }
}
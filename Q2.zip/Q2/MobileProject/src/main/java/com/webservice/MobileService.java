package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class MobileService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String mobile = request.getParameter("mobile");

        boolean valid = mobile.matches("[0-9]{10}");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if(valid)
            out.println("<h2>Valid Mobile Number</h2>");
        else
            out.println("<h2>Invalid Mobile Number</h2>");
    }
}
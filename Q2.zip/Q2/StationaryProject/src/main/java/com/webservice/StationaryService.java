package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class StationaryService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String item = request.getParameter("item");

        int price = 0;

        if(item.equalsIgnoreCase("Pen"))
            price = 10;
        else if(item.equalsIgnoreCase("Pencil"))
            price = 5;
        else if(item.equalsIgnoreCase("Book"))
            price = 50;
        else
            price = 0;

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<h2>Price : " + price + "</h2>");
    }
}
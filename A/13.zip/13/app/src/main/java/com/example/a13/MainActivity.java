package com.example.a13;

import android.os.Bundle;
import android.util.Patterns;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    // Registration Form
    EditText name, email, password, confirmPassword;
    Button registerBtn;

    // ListView
    EditText itemInput;
    Button addBtn, deleteBtn, searchBtn;
    ListView listView;

    ArrayList<String> list;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Registration Views
        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confirmPassword = findViewById(R.id.confirmPassword);

        registerBtn = findViewById(R.id.registerBtn);

        // ListView Views
        itemInput = findViewById(R.id.itemInput);

        addBtn = findViewById(R.id.addBtn);
        deleteBtn = findViewById(R.id.deleteBtn);
        searchBtn = findViewById(R.id.searchBtn);

        listView = findViewById(R.id.listView);

        // List Setup
        list = new ArrayList<>();

        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                list
        );

        listView.setAdapter(adapter);

        // Registration Button
        registerBtn.setOnClickListener(v -> validateForm());

        // Insert
        addBtn.setOnClickListener(v -> {

            String item =
                    itemInput.getText().toString();

            if (!item.isEmpty()) {

                list.add(item);

                adapter.notifyDataSetChanged();

                itemInput.setText("");

            } else {

                Toast.makeText(this,
                        "Enter Item",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Delete
        deleteBtn.setOnClickListener(v -> {

            String item =
                    itemInput.getText().toString();

            if (list.contains(item)) {

                list.remove(item);

                adapter.notifyDataSetChanged();

                Toast.makeText(this,
                        "Item Deleted",
                        Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this,
                        "Item Not Found",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Search
        searchBtn.setOnClickListener(v -> {

            String item =
                    itemInput.getText().toString();

            if (list.contains(item)) {

                Toast.makeText(this,
                        "Item Found",
                        Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(this,
                        "Item Not Found",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Registration Validation
    private void validateForm() {

        String userName =
                name.getText().toString().trim();

        String userEmail =
                email.getText().toString().trim();

        String userPass =
                password.getText().toString().trim();

        String userConfirm =
                confirmPassword.getText().toString().trim();

        // Name Check
        if (userName.isEmpty()) {

            name.setError("Enter Name");

            return;
        }

        // Email Check
        if (!Patterns.EMAIL_ADDRESS
                .matcher(userEmail)
                .matches()) {

            email.setError("Invalid Email");

            return;
        }

        // Password Check
        if (userPass.length() < 6) {

            password.setError(
                    "Password must be 6 characters");

            return;
        }

        // Confirm Password
        if (!userPass.equals(userConfirm)) {

            confirmPassword.setError(
                    "Password Not Match");

            return;
        }

        Toast.makeText(this,
                "Registration Successful",
                Toast.LENGTH_LONG).show();
    }
}
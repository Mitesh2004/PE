package com.example.a20;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Number Validation
    EditText num1, num2;
    Button displayBtn;
    TextView result;

    // Email
    EditText email, subject, message;
    Button sendBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Number Validation Views
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);

        displayBtn = findViewById(R.id.displayBtn);

        result = findViewById(R.id.result);

        // Email Views
        email = findViewById(R.id.email);

        subject = findViewById(R.id.subject);

        message = findViewById(R.id.message);

        sendBtn = findViewById(R.id.sendBtn);

        // Number Validation Button
        displayBtn.setOnClickListener(v -> validateNumbers());

        // Send Email Button
        sendBtn.setOnClickListener(v -> sendEmail());
    }

    // Q1 Program
    private void validateNumbers() {

        String n1 =
                num1.getText().toString();

        String n2 =
                num2.getText().toString();

        if (n1.isEmpty() || n2.isEmpty()) {

            result.setText("Enter Both Numbers");

            return;
        }

        int a = Integer.parseInt(n1);

        int b = Integer.parseInt(n2);

        // Reject if both > 20
        if (a > 20 && b > 20) {

            Toast.makeText(this,
                    "Both Numbers Greater Than 20. Enter Again",
                    Toast.LENGTH_LONG).show();

            num1.setText("");

            num2.setText("");

            result.setText("");

        } else {

            result.setText(
                    "Number 1 = " + a +
                            "\nNumber 2 = " + b);
        }
    }

    // Q2 Program
    private void sendEmail() {

        String to =
                email.getText().toString();

        String sub =
                subject.getText().toString();

        String msg =
                message.getText().toString();

        Intent intent =
                new Intent(Intent.ACTION_SEND);

        intent.setType("*/*");

        intent.putExtra(
                Intent.EXTRA_EMAIL,
                new String[]{to});

        intent.putExtra(
                Intent.EXTRA_SUBJECT,
                sub);

        intent.putExtra(
                Intent.EXTRA_TEXT,
                msg);

        // Dummy Attachment
        Uri uri =
                Uri.parse(
                        "android.resource://"
                                + getPackageName()
                                + "/drawable/ic_launcher_foreground");

        intent.putExtra(
                Intent.EXTRA_STREAM,
                uri);

        startActivity(
                Intent.createChooser(
                        intent,
                        "Send Email"));
    }
}
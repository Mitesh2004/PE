package com.example.a6;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText email, password, location;

    Button loginBtn, searchBtn;

    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Login Views
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);

        loginBtn = findViewById(R.id.loginBtn);

        // Map Views
        location = findViewById(R.id.location);

        searchBtn = findViewById(R.id.searchBtn);

        // Result
        result = findViewById(R.id.result);

        // Login Validation
        loginBtn.setOnClickListener(v -> validateLogin());

        // Google Map Search
        searchBtn.setOnClickListener(v -> searchLocation());
    }

    // Login Validation Method
    private void validateLogin() {

        String userEmail =
                email.getText().toString().trim();

        String userPass =
                password.getText().toString().trim();

        // Email Empty Check
        if (userEmail.isEmpty()) {

            email.setError("Email Required");

            email.requestFocus();

            return;
        }

        // Email Format Check
        if (!Patterns.EMAIL_ADDRESS
                .matcher(userEmail)
                .matches()) {

            email.setError("Invalid Email");

            email.requestFocus();

            return;
        }

        // Password Check
        if (userPass.isEmpty()) {

            password.setError("Password Required");

            password.requestFocus();

            return;
        }

        // Password Length
        if (userPass.length() < 6) {

            password.setError(
                    "Password must be 6 characters");

            password.requestFocus();

            return;
        }

        result.setText("Login Successful");
    }

    // Google Map Search Method
    private void searchLocation() {

        String loc =
                location.getText().toString();

        if (loc.isEmpty()) {

            Toast.makeText(this,
                    "Enter Location",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        Uri uri =
                Uri.parse("geo:0,0?q="
                        + Uri.encode(loc));

        Intent intent =
                new Intent(Intent.ACTION_VIEW, uri);

        intent.setPackage(
                "com.google.android.apps.maps");

        startActivity(intent);
    }
}
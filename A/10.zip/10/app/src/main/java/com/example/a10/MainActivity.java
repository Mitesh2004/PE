package com.example.a10;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Armstrong
    EditText getnum;
    Button checkBtn;

    // Spinner GUI
    Spinner spinner;
    Button applyBtn, resetBtn;
    LinearLayout layout;

    String[] colors = {
            "Select Color",
            "Red",
            "Green",
            "Blue",
            "Yellow"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Armstrong
        getnum = findViewById(R.id.getnum);
        checkBtn = findViewById(R.id.checkBtn);

        // Spinner GUI
        spinner = findViewById(R.id.spinner);

        applyBtn = findViewById(R.id.applyBtn);

        resetBtn = findViewById(R.id.resetBtn);

        layout = findViewById(R.id.layout);

        // Spinner Adapter
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(
                        this,
                        android.R.layout.simple_spinner_dropdown_item,
                        colors
                );

        spinner.setAdapter(adapter);

        // Armstrong Button
        checkBtn.setOnClickListener(v -> checkArmstrong());

        // Apply Button
        applyBtn.setOnClickListener(v -> applyColor());

        // Reset Button
        resetBtn.setOnClickListener(v -> {
            layout.setBackgroundColor(Color.WHITE);
            spinner.setSelection(0);
        });
    }

    // Armstrong Program
    private void checkArmstrong() {

        String input =
                getnum.getText().toString();

        if (input.isEmpty()) {

            Toast.makeText(this,
                    "Enter Number",
                    Toast.LENGTH_SHORT).show();

            return;
        }

        int num = Integer.parseInt(input);

        int original = num;

        int sum = 0;

        while (num > 0) {

            int digit = num % 10;

            sum = sum + (digit * digit * digit);

            num = num / 10;
        }

        if (sum == original) {

            Toast.makeText(this,
                    original + " is Armstrong Number",
                    Toast.LENGTH_LONG).show();

        } else {

            Toast.makeText(this,
                    original + " is NOT Armstrong Number",
                    Toast.LENGTH_LONG).show();
        }
    }

    // Spinner GUI Program
    private void applyColor() {

        String selected =
                spinner.getSelectedItem().toString();

        switch (selected) {

            case "Red":
                layout.setBackgroundColor(Color.RED);
                break;

            case "Green":
                layout.setBackgroundColor(Color.GREEN);
                break;

            case "Blue":
                layout.setBackgroundColor(Color.BLUE);
                break;

            case "Yellow":
                layout.setBackgroundColor(Color.YELLOW);
                break;

            default:

                Toast.makeText(this,
                        "Select Color",
                        Toast.LENGTH_SHORT).show();
        }
    }
}
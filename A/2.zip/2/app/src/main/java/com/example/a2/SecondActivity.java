package com.example.a2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    EditText num1, num2, perfectNum;
    TextView result;
    Button add, sub, mul, div, checkPerfect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // UI Layout
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(20,20,20,20);

        num1 = new EditText(this);
        num1.setHint("Enter First Number");

        num2 = new EditText(this);
        num2.setHint("Enter Second Number");

        result = new TextView(this);
        result.setTextSize(20);

        add = new Button(this);
        add.setText("Addition");

        sub = new Button(this);
        sub.setText("Subtraction");

        mul = new Button(this);
        mul.setText("Multiplication");

        div = new Button(this);
        div.setText("Division");

        perfectNum = new EditText(this);
        perfectNum.setHint("Enter Number for Perfect Check");

        checkPerfect = new Button(this);
        checkPerfect.setText("Check Perfect Number");

        // Add Views
        layout.addView(num1);
        layout.addView(num2);
        layout.addView(add);
        layout.addView(sub);
        layout.addView(mul);
        layout.addView(div);
        layout.addView(perfectNum);
        layout.addView(checkPerfect);
        layout.addView(result);

        setContentView(layout);

        // Arithmetic Operations
        add.setOnClickListener(v -> calculate("+"));

        sub.setOnClickListener(v -> calculate("-"));

        mul.setOnClickListener(v -> calculate("*"));

        div.setOnClickListener(v -> calculate("/"));

        // Perfect Number Check
        checkPerfect.setOnClickListener(v -> checkPerfectNumber());
    }

    private void calculate(String op) {

        String n1 = num1.getText().toString();
        String n2 = num2.getText().toString();

        if (n1.isEmpty() || n2.isEmpty()) {
            result.setText("Enter both numbers");
            return;
        }

        double a = Double.parseDouble(n1);
        double b = Double.parseDouble(n2);

        double res = 0;

        switch (op) {

            case "+":
                res = a + b;
                break;

            case "-":
                res = a - b;
                break;

            case "*":
                res = a * b;
                break;

            case "/":
                if (b == 0) {
                    result.setText("Cannot divide by zero");
                    return;
                }
                res = a / b;
                break;
        }

        result.setText("Result = " + res);
    }

    private void checkPerfectNumber() {

        String input = perfectNum.getText().toString();

        if (input.isEmpty()) {
            Toast.makeText(this,
                    "Enter number",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        int num = Integer.parseInt(input);

        int sum = 0;

        for (int i = 1; i <= num / 2; i++) {

            if (num % i == 0) {
                sum += i;
            }
        }

        if (sum == num && num != 0) {

            Toast.makeText(this,
                    num + " is Perfect Number",
                    Toast.LENGTH_LONG).show();

        } else {

            Toast.makeText(this,
                    num + " is NOT Perfect Number",
                    Toast.LENGTH_LONG).show();
        }
    }
}
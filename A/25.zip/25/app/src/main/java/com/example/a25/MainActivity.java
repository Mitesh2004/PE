package com.example.a25;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // SMS
    EditText phone, message;

    Button sendBtn;

    // Login
    EditText username, password;

    Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // SMS Views
        phone = findViewById(R.id.phone);

        message = findViewById(R.id.message);

        sendBtn = findViewById(R.id.sendBtn);

        // Login Views
        username = findViewById(R.id.username);

        password = findViewById(R.id.password);

        loginBtn = findViewById(R.id.loginBtn);

        // Send SMS
        sendBtn.setOnClickListener(v -> sendSMS());

        // Login
        loginBtn.setOnClickListener(v -> checkLogin());
    }

    // SMS Program
    private void sendSMS() {

        String mobile =
                phone.getText().toString();

        String msg =
                message.getText().toString();

        Intent intent =
                new Intent(Intent.ACTION_VIEW);

        intent.setData(Uri.parse("sms:" + mobile));

        intent.putExtra("sms_body", msg);

        startActivity(intent);
    }

    // Login Program
    private void checkLogin() {

        String user =
                username.getText().toString();

        String pass =
                password.getText().toString();

        if (user.equals(pass)) {

            Toast.makeText(this,
                    "Login Successful...",
                    Toast.LENGTH_LONG).show();

        } else {

            Toast.makeText(this,
                    "Invalid Login",
                    Toast.LENGTH_LONG).show();
        }
    }
}
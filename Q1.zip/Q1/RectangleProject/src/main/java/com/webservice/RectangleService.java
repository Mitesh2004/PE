package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RectangleService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        double length = Double.parseDouble(request.getParameter("length"));

        double breadth = Double.parseDouble(request.getParameter("breadth"));

        double height = Double.parseDouble(request.getParameter("height"));

        double area = length * breadth;

        double volume = length * breadth * height;

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<h2>Area = " + area + "</h2>");
        out.println("<h2>Volume = " + volume + "</h2>");
    }
}
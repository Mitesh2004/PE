package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FactorialService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        int num = Integer.parseInt(request.getParameter("number"));

        long fact = 1;

        for(int i = 1; i <= num; i++) {
            fact = fact * i;
        }

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<h2>Factorial = " + fact + "</h2>");
    }
}
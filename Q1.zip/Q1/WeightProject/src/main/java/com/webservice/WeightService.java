package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class WeightService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        double kg = Double.parseDouble(request.getParameter("kg"));

        double gram = kg * 1000;

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<h2>Weight in Gram = " + gram + "</h2>");
    }
}
package com.webservice;

import java.io.*;
import java.util.Date;

import javax.servlet.*;
import javax.servlet.http.*;

public class GreetingService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");

        Date d = new Date();

        int hour = d.getHours();

        String message = "";

        if(hour < 12)
            message = "Good Morning";
        else if(hour < 17)
            message = "Good Afternoon";
        else
            message = "Good Evening";

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<h2>" + message + " " + name + "</h2>");
    }
}
package com.webservice;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class VowelService extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String str = request.getParameter("text");

        int count = 0;

        str = str.toLowerCase();

        for(int i = 0; i < str.length(); i++) {

            char ch = str.charAt(i);

            if(ch == 'a' || ch == 'e' || ch == 'i' ||
               ch == 'o' || ch == 'u') {

                count++;
            }
        }

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();

        out.println("<h2>Number of Vowels = " + count + "</h2>");
    }
}